package com.example.HowFastCanEat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HowFastCanEatApplicationTests {

	@Test
	void contextLoads() {
	}

}
