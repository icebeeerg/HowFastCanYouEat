package com.example.HowFastCanEat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HowFastCanEatApplication {

	public static void main(String[] args) {
		SpringApplication.run(HowFastCanEatApplication.class, args);
	}

}
